chrome.runtime.onInstalled.addListener(() => {
  console.log("Storage Copier extension installed.");
});

// Add listeners and logic to copy session/local storage here.
